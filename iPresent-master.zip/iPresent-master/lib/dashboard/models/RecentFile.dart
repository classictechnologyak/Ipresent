class RecentFile {
  final String? icon, title;

  RecentFile({
    this.icon,
    this.title,
  });
}

List demoRecentFiles = [
  RecentFile(
    icon: "assets/icons/jan.svg",
    title: "View Attendance History",
  ),
  // RecentFile(
  //   icon: "assets/icons/feb.svg",
  //   title: "February",
  // ),
  // RecentFile(
  //   icon: "assets/icons/march.svg",
  //   title: "March",
  // ),
  // RecentFile(
  //   icon: "assets/icons/april.svg",
  //   title: "April",
  // ),
  // RecentFile(
  //   icon: "assets/icons/may.svg",
  //   title: "May",
  // ),
  // RecentFile(
  //   icon: "assets/icons/june.svg",
  //   title: "June",
  // ),
  // RecentFile(
  //   icon: "assets/icons/jan.svg",
  //   title: "July",
  // ),
  // RecentFile(
  //   icon: "assets/icons/feb.svg",
  //   title: "August",
  // ),
  // RecentFile(
  //   icon: "assets/icons/march.svg",
  //   title: "Septmber",
  // ),
  // RecentFile(
  //   icon: "assets/icons/april.svg",
  //   title: "October",
  // ),
  // RecentFile(
  //   icon: "assets/icons/may.svg",
  //   title: "November",
  // ),
  // RecentFile(
  //   icon: "assets/icons/june.svg",
  //   title: "December",
  // ),
//   RecentFile(
//     icon: "assets/icons/excle_file.svg",
//     title: "Excel File",
//     date: "25-02-2021",
//     size: "34.5mb",
//   ),
];
