import 'package:flutter/material.dart';

const primaryColor = Color(0xFF2697FF);
Color? secondaryColor = Colors.grey[350];
const bgColor = Color(0xFF212332);

const defaultPadding = 16.0;
