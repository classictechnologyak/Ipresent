class TypeLogo {
  static String facebook = 'assets/facebook.png';
  static String google = 'assets/google.png';
  static String apple = 'assets/apple.png';
  static String userPassword = 'assets/user_password.png';
}

class SigninScreenTypeSignModel {
  Function callFunction;
  String? logo;

  SigninScreenTypeSignModel({this.logo, required this.callFunction});
}
