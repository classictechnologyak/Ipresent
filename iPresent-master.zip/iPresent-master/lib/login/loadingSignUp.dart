import 'package:flutter/material.dart';

class LoadingSignUp extends StatelessWidget {
  final String? textLoading;
  final Color? colorText;
  final double? elevation;

  final Color? backgroundColor;

  LoadingSignUp(
      {this.textLoading, this.colorText, this.elevation, this.backgroundColor});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        height: 80,
        width: 150,
        child: Card(
          elevation: this.elevation,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          color: Color(0xFFF3F3F5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              new Center(
                child: new SizedBox(
                  height: 30.0,
                  width: 30.0,
                  child: new CircularProgressIndicator(
                    value: null,
                    strokeWidth: 2.0,
                  ),
                ),
              ),
              new Container(
                margin: const EdgeInsets.only(top: 5.0),
                child: new Center(
                  child: new Text(
                    this.textLoading!,
                    style: new TextStyle(color: this.colorText),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
