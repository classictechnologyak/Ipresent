import 'package:stacked/stacked.dart';

class HomeScreenModel extends BaseViewModel {}
