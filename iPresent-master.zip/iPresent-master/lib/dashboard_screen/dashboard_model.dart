import 'package:stacked/stacked.dart';

class DashboardViewModel extends BaseViewModel {}
